<?php

$conn = mysqli_connect('localhost','root','','dbcooking') or die('connection failed');

?>